//
//  CommonExtensions.swift
//  ARDWM_Client
//
//  Created by Dhananjay on 10/6/16.
//  Copyright © 2016 Credencys. All rights reserved.
//

import UIKit

class CommonExtensions: NSObject {
    
}

extension Double {
    func format(f: String) -> Double {
        return Double(String(format: "%\(f)f", self))!
    }
    
    func dashboardFormat(decimalPoints:Int, primaryFont: CGFloat, secondaryFont:CGFloat) -> NSMutableAttributedString {
        var mainString = ""
        var currencyLength = 0
        if self == 0 {
            mainString = "—"
            currencyLength = 0
        }
        else if self < 100000 {
            mainString = "\(Double(self/1000).format(f: ".\(decimalPoints)"))K"
            currencyLength = 1
        } else if self < 10000000 {
            mainString = "\(Double(self/100000).format(f: ".\(decimalPoints)"))L"
            currencyLength = 1
        } else if self >= 10000000 {
            mainString = "\(Double(self/10000000).format(f: ".\(decimalPoints)"))Cr"
            currencyLength = 2
        }
        else {
            mainString = "-"
            currencyLength = 0
        }
        return Constant.setAttributedText(mainString: mainString, primaryFontName: "MuseoSans-100", secondaryFontName: "MuseoSans-100", MainFontSize: primaryFont, SubFontSize: secondaryFont, subStringLength: currencyLength)
    }
    
    var amountInWords : String {
        var amountValue = self
        var valueInWords = ""
        //Crores
        if amountValue >= 10000000 {
            let temp = Int(amountValue / 10000000)
            if temp > 1 {
                valueInWords = "\(temp.integerInWords) crores "
            }
            else if temp == 1 {
                valueInWords = "\(temp.integerInWords) crore "
            }
            amountValue = fmod(amountValue, 10000000)
        }
        //Lakhs
        if amountValue >= 100000 {
            let temp = Int(amountValue / 100000)
            if temp > 1 {
                valueInWords = valueInWords.appending("\(temp.integerInWords) lacs ")
            }
            else if temp == 1 {
                valueInWords = valueInWords.appending("\(temp.integerInWords) lac ")
            }
            amountValue = fmod(amountValue, 100000)
        }
        //Thousands
        if amountValue >= 1000 {
            let temp = Int(amountValue / 1000)
            valueInWords = valueInWords.appending("\(temp.integerInWords) thousand ")
            amountValue = fmod(amountValue, 1000)
        }
        if amountValue > 0 {
            valueInWords = valueInWords.appending("\(Int(amountValue).integerInWords)")
        }
        return valueInWords.capitalizingFirstLetter()
    }
}

extension String {
    func capitalizingFirstLetter() -> String {
        let first = String(characters.prefix(1)).capitalized
        let other = String(characters.dropFirst())
        return first + other
    }
    
    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
}

extension Date {
    
    var DateTimeformatted : String {
        let formatter = DateFormatter()
        formatter.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        formatter.dateFormat = "dd/MM/yyyy HH:mm:ss"
        return formatter.string(from: self)
    }
    
    var Dateformatted:String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MMM-yyyy"
        return formatter.string(from: self)
    }
    
    func DateformattedWith(format:String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        return formatter.string(from: self)
    }
    
    var DateLocalformatted:String {
        let formatter = DateFormatter()
        formatter.timeZone = NSTimeZone.local
        formatter.dateFormat = "dd/MM/yyyy" // "dd/MM/yyyy hh:mm:ss a"
        return formatter.string(from: self)
    }
    
    var TimeLocalformatted:String {
        let formatter = DateFormatter()
        formatter.timeZone = NSTimeZone.local
        formatter.dateFormat = "hh:mm a" // "dd/MM/yyyy hh:mm:ss a"
        return formatter.string(from: self)
    }
    
    var DDformattedLocal:String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MMM-yy"
        return formatter.string(from: self)
    }
    
    func DDformattedWithLocal(format:String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        return formatter.string(from: self)
    }
}

extension String {
    
    var asDate:Date! {
        let styler = DateFormatter()
        styler.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        styler.dateFormat = "yyyy-MM-dd HH:mm:ss z"
        return styler.date(from: self)
    }
    
    func asDateFormattedWith(format:String) -> Date! {
        let styler = DateFormatter()
        styler.dateFormat = format
        return styler.date(from: self)
    }
    
    func trim() -> String {
        return self.trimmingCharacters(in: NSCharacterSet.whitespaces)
    }
    
    func isValidEmail() -> Bool {
        let stricterFilter: Bool = false
        let stricterFilterString: String = "^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$"
        let laxString: String = "^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$"
        let emailRegex: String = stricterFilter ? stricterFilterString : laxString
        let emailTest: NSPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: self)
    }
    
    func isValidPanCard() -> Bool {
        let panRegEx = "[A-Z]{5}[0-9]{4}[A-Z]{1}"
        let panTest = NSPredicate(format:"SELF MATCHES %@", panRegEx)
        return panTest.evaluate(with: self)
    }
    
    var asPutDateLocal:Date! {
        let styler = DateFormatter()
        styler.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        styler.dateFormat = "dd/MM/yyyy"
        //"MM/dd/yyyy hh:mm:ss a"
        return styler.date(from: self)
    }
    
    var asDateLocal:Date! {
        let styler = DateFormatter()
        styler.timeZone = NSTimeZone(name: "UTC") as TimeZone!
        styler.dateFormat = "dd/MMM/yyyy HH:mm:ss"
        return styler.date(from: self)
    }
}

//----------------------------------------------------------
struct Number {
    static let formatterWithSepator: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.groupingSeparator = ","
        formatter.numberStyle = .decimal
        //***formatter.locale = NSLocale(localeIdentifier: "en_IN")***//
        return formatter
    }()
}

//For seting alpha automatically
extension UIButton {
    override open var isEnabled:Bool{
        didSet {
            self.alpha = isEnabled ? 1.0 : 0.2
            //Your code
        }
    }
}

extension Integer {
    var stringFormatedWithSepator: String {
        let value = hashValue as NSNumber
        return Number.formatterWithSepator.string(from: value) ?? ""
    }
    
    var integerInWords: String {
        let numberFormatter = NumberFormatter()
        numberFormatter.locale = NSLocale(localeIdentifier: NSLocale.localeIdentifier(fromComponents: [NSLocale.Key.languageCode.rawValue: "en", NSLocale.Key.countryCode.rawValue: "IN"])) as Locale!
        numberFormatter.numberStyle = NumberFormatter.Style.spellOut
        
        let value = hashValue as NSNumber
        let wordNumber = numberFormatter.string(from: value)!
        return wordNumber
    }
}

extension Array where Element: Equatable {
    
    // Remove first collection element that is equal to the given `object`:
    mutating func remove(object: Element) {
        if let index = index(of: object) {
            remove(at: index)
        }
    }
}

